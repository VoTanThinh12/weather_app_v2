import 'package:flutter/material.dart';

final backgroundColor = Color(0xFF1a1a16);
final buttonColor = Color(0xFFd98f1e);
